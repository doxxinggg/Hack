This program needs to hack IP cameras CCTV in the world.
For setup you need to write these commands in termux:
```
apt-get install python3
apt-get install git
git clone https://github.com/yan4ikyt/webhack
cd webhack
pip3 install requests
python3 WebHack.py
```

Done!
To start you need write command: `python3 webhack.py`

*Thanks for downloading and using this program I'm really happy :)*

*Subscribe to [Yan4ik Channel on YouTube](https://youtube.com/channel/UCu6l8wKI7WGlwoD1It_vcdw)!*
